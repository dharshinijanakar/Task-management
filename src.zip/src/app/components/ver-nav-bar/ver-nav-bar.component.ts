import { Component } from '@angular/core';

@Component({
  selector: 'app-ver-nav-bar',
  templateUrl: './ver-nav-bar.component.html',
  styleUrls: ['./ver-nav-bar.component.css']
})
export class VerNavBarComponent {

}
