import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VerNavBarComponent } from './ver-nav-bar.component';

describe('VerNavBarComponent', () => {
  let component: VerNavBarComponent;
  let fixture: ComponentFixture<VerNavBarComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [VerNavBarComponent]
    });
    fixture = TestBed.createComponent(VerNavBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
